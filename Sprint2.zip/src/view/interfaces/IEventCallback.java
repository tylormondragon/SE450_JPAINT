package view.interfaces;

public interface IEventCallback {
	void run();
}
