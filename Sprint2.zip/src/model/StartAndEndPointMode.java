package model;

public enum StartAndEndPointMode {
    DRAW,
    SELECT,
    MOVE
}
